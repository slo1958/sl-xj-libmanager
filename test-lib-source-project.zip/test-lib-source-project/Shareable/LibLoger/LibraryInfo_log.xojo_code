#tag Module
Protected Module LibraryInfo_log
	#tag Constant, Name = LibraryAuthor, Type = String, Dynamic = False, Default = \"alpha", Scope = Protected
	#tag EndConstant

	#tag Constant, Name = LibraryName, Type = String, Dynamic = False, Default = \"abcd", Scope = Protected
	#tag EndConstant

	#tag Constant, Name = LibraryVersion, Type = String, Dynamic = False, Default = \"1.2.3", Scope = Protected
	#tag EndConstant


	#tag ViewBehavior
		#tag ViewProperty
			Name="Name"
			Visible=true
			Group="ID"
			InitialValue=""
			Type="String"
			EditorType=""
		#tag EndViewProperty
		#tag ViewProperty
			Name="Index"
			Visible=true
			Group="ID"
			InitialValue="-2147483648"
			Type="Integer"
			EditorType=""
		#tag EndViewProperty
		#tag ViewProperty
			Name="Super"
			Visible=true
			Group="ID"
			InitialValue=""
			Type="String"
			EditorType=""
		#tag EndViewProperty
		#tag ViewProperty
			Name="Left"
			Visible=true
			Group="Position"
			InitialValue="0"
			Type="Integer"
			EditorType=""
		#tag EndViewProperty
		#tag ViewProperty
			Name="Top"
			Visible=true
			Group="Position"
			InitialValue="0"
			Type="Integer"
			EditorType=""
		#tag EndViewProperty
	#tag EndViewBehavior
End Module
#tag EndModule
